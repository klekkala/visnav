package pxb.java.nio.file;


public enum  FileVisitResult {
    CONTINUE,TERMINATE,SKIP_SUBTREE, SKIP_SIBLINGS;
}
